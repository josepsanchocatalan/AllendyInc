package com.example.allendy.Clases;

public class Rol  extends Usuario {

    private Usuario Usser;
    private boolean Rol;

    /* funciones

    visualizar contenido compartido;*/

}
