package com.example.allendy;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class editarNotaController {
    @javafx.fxml.FXML
    private Button botonEditarNota;
    @javafx.fxml.FXML
    private TextField editarNombreNota;
    @javafx.fxml.FXML
    private Button botonCancelarNotaPopUp;

    @javafx.fxml.FXML
    public void onBotonEditarNotaPop(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void onBotonCancelarNotaPop(ActionEvent actionEvent) {
    }
}
