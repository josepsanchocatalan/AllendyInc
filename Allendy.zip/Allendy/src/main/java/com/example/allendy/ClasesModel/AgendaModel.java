package com.example.allendy.ClasesModel;

import com.example.allendy.Clases.Agenda;
import com.example.allendy.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AgendaModel {

    //Funcion insertar agenda
    public static void InsertarAgenda(Agenda a1){

        DBUtil db = new DBUtil();
        Connection con = db.getConexion();

        Integer idAg= a1.getIdAgenda();
        Integer iduserAg= a1.getIdUsuarioAgenda();
        String nombre = a1.getNombreAgenda();

        try {
            String insertSql = "INSERT INTO allendy.agenda (id_agendaAgenda, id_usuarioAgenda,Nombre) VALUES (?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(insertSql);
            stmt.setInt(1, idAg);
            stmt.setInt(2, iduserAg);
            stmt.setString(3, nombre);

            stmt.execute();
            stmt.close();
        }catch(SQLException e){
            e.printStackTrace();
        }

    }

    //Funcion eliminar agenda/
    public boolean EliminarAgenda(Agenda a1){
        boolean verificacion = false;

        DBUtil db = new DBUtil();
        Connection con = db.getConexion();
        try {

            String query = "";

            PreparedStatement stmt = con.prepareStatement(query);
            stmt.execute();

        }catch(SQLException e){
            e.printStackTrace();
        }

        return verificacion;
    }

    //Funcion modificar agenda
    public boolean ModificarAgenda(Agenda a1){
        boolean verificacion = false;


        DBUtil db = new DBUtil();
        Connection con = db.getConexion();

        try {


            String query = "";

            PreparedStatement stmt = con.prepareStatement(query);
            stmt.execute();

        }catch(SQLException e){
            e.printStackTrace();
        }

        return verificacion;
    }

    //Funcion recuperar agenda
    public boolean RecuperarAgenda(Agenda a1){
        boolean verificacion = false;

        DBUtil db = new DBUtil();
        Connection con = db.getConexion();

        try {

            String query = "";

            PreparedStatement stmt = con.prepareStatement(query);
            stmt.execute();

        }catch(SQLException e){
            e.printStackTrace();
        }

        return verificacion;
    }
}
